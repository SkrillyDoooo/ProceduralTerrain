﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CreateAssetMenu(menuName = "Warpath Terrain Data/Navigation")]
public class NavMapSettings : UpdateableData
{
    [Range(0, 16)]
    public int LOD;

    public int skipIncrement
    {
        get
        {
            return (LOD == 0) ? 1 : LOD * 2;
        }
    }
}
