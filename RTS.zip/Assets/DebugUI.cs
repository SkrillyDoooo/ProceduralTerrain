﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class DebugUI : MonoBehaviour
{
    Image item;
    VisualElement debugRT;
    public void SetRenderTexture(RenderTexture rt)
    {
        InitImage();
        item.image = rt;
        item.image.width = rt.width;
        item.image.height = rt.height;

        item.style.width = 176;
        item.style.height = 176;
    }

    void InitImage()
    {
        if (item != null)
            return;

        var uiDocument = GetComponent<UIDocument>();
        item = new Image();
        var root = uiDocument.rootVisualElement;
        root = root.Query(name: "root");
        root.Add(item);
    }
    // Start is called before the first frame update
    void Start()
    {
        InitImage();
    }
}
