﻿using UnityEngine;

public class ReadOnlyEditorAttribute : PropertyAttribute
{

}