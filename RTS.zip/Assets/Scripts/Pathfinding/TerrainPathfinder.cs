﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainPathFinder
{
    TerrainPathFinderSettings settings;
    float GridStepSize = 2.5f;
    float WithinRangeRadius = 5;

    Dictionary<GridPoint, bool> closedSet = new Dictionary<GridPoint, bool>();
    Dictionary<GridPoint, bool> openSet = new Dictionary<GridPoint, bool>();

    //cost of start to this key node
    Dictionary<GridPoint, int> gScore = new Dictionary<GridPoint, int>();
    //cost of start to goal, passing through key node
    Dictionary<GridPoint, int> fScore = new Dictionary<GridPoint, int>();

    Dictionary<GridPoint, GridPoint> nodeLinks = new Dictionary<GridPoint, GridPoint>();

    int attempts = 0;

    int tryCountMax = 1000;
    int tryCount;
    GridPoint currentStart;
    float chunkWorldSize;

    List<GameObject> debugGO = new List<GameObject>();
    public TerrainPathFinder(TerrainPathFinderSettings settings)
    {
        this.settings = settings;
    }

    public void FindPath(TerrainGenerator terrain, GridPoint start, GridPoint goal, int refinementLevel, Stack<GridPoint> gridPoints, bool debug = false)
    {

        refinementLevel = (refinementLevel == 0) ? 1 : refinementLevel;
        GridStepSize = TerrainGenerator.Instance.meshSettings.meshScale * refinementLevel;
        WithinRangeRadius = TerrainGenerator.Instance.meshSettings.meshScale * refinementLevel;
        chunkWorldSize = TerrainGenerator.Instance.meshSettings.meshWorldSize / (refinementLevel == 16 ? 1 : 2);


        closedSet.Clear();
        openSet.Clear();
        gScore.Clear();
        fScore.Clear();
        nodeLinks.Clear();

        openSet[start] = true;
        gScore[start] = 0;
        fScore[start] = Heuristic(start, goal);
        tryCount = 0;
        currentStart = start;
        while (openSet.Count > 0)
        {
            var current = nextBest();
            tryCount++;
            if (Distance(current, goal) < WithinRangeRadius || tryCount >= tryCountMax)
            {
                Reconstruct(current, gridPoints);
                return;
            }


            openSet.Remove(current);
            closedSet.Add(current, true);

            foreach (var neighbor in Neighbors(terrain, current, (refinementLevel == 16)))
            {
                if (closedSet.ContainsKey(neighbor))
                    continue;

                var projectedG = getGScore(current) + 1;

                if (!openSet.ContainsKey(neighbor))
                    openSet[neighbor] = true;
                else if (projectedG >= getGScore(neighbor))
                    continue;

                //record it
                nodeLinks.Add(neighbor, current);
                gScore.Add(neighbor, projectedG);
                fScore.Add(neighbor, projectedG + Heuristic(neighbor, goal));
            }
        }
    }

    private static float Distance(GridPoint x, GridPoint y)
    {
        return Vector2.Distance(new Vector2(x.X, x.Y), new Vector2(y.X, y.Y));
    }

    private int Heuristic(GridPoint start, GridPoint goal)
    {
        var dx = goal.X - start.X;
        var dy = goal.Y - start.Y;
        return Math.Abs(dx) + Math.Abs(dy);
    }

    private int getGScore(GridPoint pt)
    {
        int score = int.MaxValue;
        gScore.TryGetValue(pt, out score);
        return score;
    }


    private int getFScore(GridPoint pt)
    {
        int score = int.MaxValue;
        fScore.TryGetValue(pt, out score);
        return score;
    }

    public IEnumerable<GridPoint> Neighbors(TerrainGenerator terrain, GridPoint center, bool major)
    {

        GridPoint pt = new GridPoint(center.X - GridStepSize, center.Y - GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        pt = new GridPoint(center.X, center.Y - GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        pt = new GridPoint(center.X + GridStepSize, center.Y - GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        //middle row
        pt = new GridPoint(center.X - GridStepSize, center.Y, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        pt = new GridPoint(center.X + GridStepSize, center.Y, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;


        //bottom row
        pt = new GridPoint(center.X - GridStepSize, center.Y + GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        pt = new GridPoint(center.X, center.Y + GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;

        pt = new GridPoint(center.X + GridStepSize, center.Y + GridStepSize, major);
        if (IsValidNeighbor(terrain, pt))
            yield return pt;


    }

    public bool IsValidNeighbor(TerrainGenerator terrain, GridPoint pt)
    {
        int x = pt.X;
        int y = pt.Y;
        float normalizedHeight = terrain.GetHeightAtCoord(new Vector2(pt.X, pt.Y)) / terrain.MaxHeight;
        return normalizedHeight < settings.maxTraversableHeight && normalizedHeight > settings.minTraversableHeight && Distance(pt, currentStart) < chunkWorldSize;
    }

    private void Reconstruct(GridPoint current, Stack<GridPoint> points)
    {
        while (nodeLinks.ContainsKey(current))
        {
            points.Push(current);
            current = nodeLinks[current];
        }
    }

    private GridPoint nextBest()
    {
        int best = int.MaxValue;
        GridPoint bestPt = null;
        foreach (var node in openSet.Keys)
        {
            var score = getFScore(node);
            if (score < best)
            {
                bestPt = node;
                best = score;
            }
        }


        return bestPt;
    }

}
public class GridPoint
{
    public int X, Y;
    public bool isMajorNode;
    public GridPoint(int x, int y, bool major = false) { X = x; Y = y; isMajorNode = major; }
    public GridPoint(float x, float y, bool major = false) { X = (int)x; Y = (int)y; isMajorNode = major; }

    public GridPoint(Vector3 v3, bool major = false) { X = (int)v3.x; Y = (int)v3.z; isMajorNode = major; }
    public GridPoint(Vector2 v2, bool major = false) { X = (int)v2.x; Y = (int)v2.y; isMajorNode = major; }

}
