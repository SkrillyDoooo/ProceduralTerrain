﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class NavMapGenerator
{
    public static NavMap GenerateNavMap(float[,] heightMap, NavMapSettings navMapSettings)
    {
        int mapDimension = heightMap.GetLength(0);
        int navMapDimension = (mapDimension - 1) / navMapSettings.skipIncrement + 1;

        float[,] navMapValues = new float[navMapDimension, navMapDimension];

        for (int x = 0; x < mapDimension; x += navMapSettings.skipIncrement)
        {
            for(int y = 0; y < mapDimension; y+= navMapSettings.skipIncrement)
            {
                navMapValues[x/navMapSettings.skipIncrement, y/navMapSettings.skipIncrement] = heightMap[x, y];
            }
        }

        return new NavMap(navMapValues, navMapDimension);
    }
}


public struct NavMap
{
    public readonly float[,] values;
    public readonly int dimension;

    public NavMap(float[,] values, int dimension)
    {
        this.values = values;
        this.dimension = dimension;
    }
}

