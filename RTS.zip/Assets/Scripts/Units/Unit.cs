﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class Unit : WarpathObject, ISelectableObject
{

    private Vector3 TargetPosition;
    public float speed = 1.0f;
    private bool moving = true;
    public TerrainPathFinderSettings settings;
    // Update is called once per frame
    TerrainPathFinder pathFinder;

    Stack<GridPoint> gridPoints;
    Stack<GridPoint> refinedPoints;

    public bool debug;
    List<GameObject> debugGameObjects = new List<GameObject>();

    UnitUI unitUI;

    protected override void Start()
    {
        unitUI = GetComponent<UnitUI>();
        base.Start();
    }

    public void InitPathFinder()
    {
        pathFinder = new TerrainPathFinder(settings);
        gridPoints = new Stack<GridPoint>(1000);
        refinedPoints = new Stack<GridPoint>(1000);
    }

    public void SetTargetPosition(Vector3 pose)
    {
        if(pathFinder == null)
            InitPathFinder();

        if (TerrainGenerator.Instance.GetHeightAtCoord(new Vector2(pose.x, pose.z))/TerrainGenerator.Instance.MaxHeight >= settings.maxTraversableHeight)
            return;

        var goal = new GridPoint(pose.x, pose.z, true);
        var start = new GridPoint(transform.position, true);
        gridPoints.Clear();
        pathFinder.FindPath(TerrainGenerator.Instance, start, goal, 16, gridPoints);
        gridPoints.Push(start);
        if (gridPoints.Count == 1)
        {
            RefinePath(start, goal);
        }
        UpdateDebugStuff();
        UpdateDestination();

        moving = true;
    }

    void UpdateDebugStuff()
    {
        if (debug)
        {
            GridPoint[] gridPointArray = gridPoints.ToArray();
            foreach (GameObject go in debugGameObjects)
            {
                Destroy(go);
            }
            debugGameObjects.Clear();
            foreach (GridPoint gp in gridPointArray)
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                go.transform.localScale = Vector3.one * TerrainGenerator.Instance.meshSettings.meshScale;
                go.transform.position = new Vector3(gp.X, TerrainGenerator.Instance.GetHeightAtCoord(new Vector2(gp.X, gp.Y)), gp.Y);
                debugGameObjects.Add(go);
            }
        }
    }

    void Update()
    {
        if (!moving)
            return;
        UpdateTargetHeight();
        transform.position = Vector3.MoveTowards(transform.position, TargetPosition, Time.deltaTime * speed);
        if (transform.position == TargetPosition)
        {
            if(gridPoints.Count > 0)
            {
                UpdateDestination();
            }
            else
            {
                moving = false;
            }
        }
    }

    private void UpdateTargetHeight()
    {
        TargetPosition.y = TerrainGenerator.Instance.GetHeightAtCoord(new Vector2(transform.position.x, transform.position.z)) + 1;
        Vector3 v = transform.position;
        v.y = TargetPosition.y ;
        transform.position = v ;
    }

    void UpdateDestination()
    {
        GridPoint gridPoint = gridPoints.Pop();
        if (gridPoint.isMajorNode && gridPoints.Count > 0)
        {
            GridPoint goal = gridPoints.Peek();
            RefinePath(gridPoint, goal);
        }

        TargetPosition = new Vector3(gridPoint.X, 0, gridPoint.Y);
        UpdateDebugStuff();
    }

    void RefinePath(GridPoint start, GridPoint finish)
    {
        if (finish.isMajorNode)
        {
            refinedPoints.Clear();
            pathFinder.FindPath(TerrainGenerator.Instance, start, finish, 4, refinedPoints);
            foreach (var gridPoint in refinedPoints.Reverse()) // TODO:: FUCK LINQ? NOOOOO
            {
                gridPoints.Push(gridPoint);
            }
        }
    }

    public override ContextPanelData GetContextPanelData()
    {
        return unitUI.GetContextPanelData();
    }

    public void SetInfoPanelRoot(VisualElement root)
    {
        unitUI.SetInfoPanelRoot(root);
    }

    public override void Deselect()
    {
        base.Deselect();
    }

    public override void ContextButtonPressed(int index)
    {
        throw new NotImplementedException();
    }

    public override void CommandButtonPressed(int buttonId)
    {
        throw new NotImplementedException();
    }

    public override void Select(VisualElement root)
    {
        base.Select(root);
    }

    public override void RightClick(Vector3 rightClickPoint)
    {
        SetTargetPosition(rightClickPoint);
    }

    protected override void DestroyWarpathObject()
    {
        RemoveObjectFromSelectionList();
        Destroy(gameObject, 0.5f);
        PlayerManifest.Instance.RemoveUnit(transform);
    }
}
